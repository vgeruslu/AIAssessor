print("Hello, This Is the AI Grading Tool!")
